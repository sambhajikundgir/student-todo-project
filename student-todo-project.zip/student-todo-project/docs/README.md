Student + Todo Project
----------------------
How to run (XAMPP):
1. Put the 'student-todo-project' folder into your XAMPP htdocs directory (e.g., C:\xampp\htdocs\)
2. Import sql/init.sql into phpMyAdmin to create database and table.
3. Start Apache and MySQL in XAMPP.
4. Open http://localhost/student-todo-project/public/index.html
Notes:
- Update includes/db.php if your MySQL password is not empty.
- The Todo app is pure JS (public/todo.html).
